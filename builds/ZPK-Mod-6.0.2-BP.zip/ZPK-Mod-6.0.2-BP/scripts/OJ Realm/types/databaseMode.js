export var Mode;
(function (Mode) {
    Mode["practiceData"] = "practiceData";
    Mode["coordinatorConfig"] = "coordinatorConfig";
    Mode["coordinatorToggle"] = "coordinatorToggle";
    Mode["coordinatorNotificationToggle"] = "coordinatorNotificationToggle";
    Mode["saves"] = "saves";
})(Mode || (Mode = {}));
