import "./cmds/help";
import "./cmds/about";
import "./cmds/setlb";
import "./cmds/clearlb";
import "./cmds/clearpb";
import "./cmds/setting";
