import { Server, Thread } from "./../../@library/minecraft/Minecraft.js";
import { zpkModOn } from "./../index.js";
export function registerCommand(registerInformation, callback) {
    zpkModOn &&
        Server.command.register(registerInformation, (player, msg, args) => {
            const thread = new Thread();
            thread.start(function* (player, msg, args) {
                yield callback(player, msg, args);
            }, player, msg, args);
            return thread;
        });
}
