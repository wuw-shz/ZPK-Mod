import { registerCommand, settingUI } from "./../../index.js";
const regInfo = {
    name: "setting",
    description: "Open ZPK Mod Setting GUI.",
    aliases: ["st"],
};
registerCommand(regInfo, (player) => {
    settingUI(player);
});
