import { InitialData } from "./../index.js";
export function Database(player) {
    return new Proxy(InitialData, {
        get(_, key) {
            return player.getDynamicProperty(key) ?? InitialData[key];
        },
        set(_, key, value) {
            player.setDynamicProperty(key, typeof value == "number" ? (isFinite(value) ? value : "N/A") : value);
            return true;
        },
    });
}
