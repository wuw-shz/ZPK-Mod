export * from "config";
export * from "./database/index";
export * from "./ui/index";
export * from "./command/index";
import "./command/index";
import "./main";
