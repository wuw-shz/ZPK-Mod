import { system } from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import { Database } from "./../index.js";
/*Setting UI*/
export function settingUI(player) {
    run(() => {
        const menu = new ui.ActionFormData();
        menu.title("§lZPK Mod Setting");
        menu.button("GUI");
        menu.button("Texts");
        menu.button("Other");
        forceShow(player, menu).then((menu) => {
            if (menu.canceled)
                return;
            [GUIUI, TextsUI, OtherUI][menu.selection](player);
        });
    });
}
/*GUI UI*/
export function GUIUI(player) {
    run(() => {
        const db = Database(player);
        db.befTFac;
        const gui = new ui.ModalFormData();
        gui.title("GUI Setting");
        gui.slider("Pos Precition", 2, 20, 1, db.pTF);
        gui.slider("Rot Precision", 0, 20, 1, db.rTF);
        gui.toggle(`Separate GUI\n${db.separateGui ? "§8(§7yes§8/no)" : "§8(yes/§7no§8)"}`, db.separateGui);
        const def = (def) => (def ? "§8(§7show§8/hide)" : "§8(show/§7hide§8)");
        gui.toggle(`Position\n${def(db.showpos)}`, db.showpos);
        gui.toggle(`Pitch\n${def(db.showpit)}`, db.showpit);
        gui.toggle(`Facing\n${def(db.showfac)}`, db.showfac);
        gui.toggle(`Jump Angle\n${def(db.showja)}`, db.showja);
        gui.toggle(`Hit Angle\n${def(db.showhita)}`, db.showhita);
        gui.toggle(`Speed\n${def(db.showspeed)}`, db.showspeed);
        gui.toggle(`Total Speed\n${def(db.showttspeed)}`, db.showttspeed);
        gui.toggle(`Tier\n${def(db.showtier)}`, db.showtier);
        gui.toggle(`Last Landing\n${def(db.showland)}`, db.showland);
        gui.toggle(`Hit\n${def(db.showhit)}`, db.showhit);
        gui.toggle(`Offset\n${def(db.showos)}`, db.showos);
        gui.toggle(`PB\n${def(db.showpb)}`, db.showpb);
        gui.toggle(`Last Turning\n${def(db.showLastTurning)}`, db.showLastTurning);
        gui.toggle(`Last Timing\n${def(db.showLastTiming)}`, db.showLastTiming);
        forceShow(player, gui).then((gui) => {
            if (gui.canceled)
                return settingUI(player);
            db.pTF = gui.formValues[0];
            db.rTF = gui.formValues[1];
            db.separateGui = gui.formValues[2];
            db.showpos = gui.formValues[3];
            db.showpit = gui.formValues[4];
            db.showfac = gui.formValues[5];
            db.showja = gui.formValues[6];
            db.showhita = gui.formValues[7];
            db.showspeed = gui.formValues[8];
            db.showttspeed = gui.formValues[9];
            db.showtier = gui.formValues[10];
            db.showland = gui.formValues[11];
            db.showhit = gui.formValues[12];
            db.showos = gui.formValues[13];
            db.showpb = gui.formValues[14];
            db.showLastTurning = gui.formValues[15];
            db.showLastTiming = gui.formValues[16];
        });
    });
}
/*Texts UI*/
export function TextsUI(player) {
    run(() => {
        const db = Database(player);
        const texts = new ui.ModalFormData();
        texts.title("Text Setting");
        texts.textField("Labels Color\n§o§8(0-9/a-u)", "0-9/a-u", db.tc1);
        texts.textField("Value Color\n§o§8(0-9/a-u)", "0-9/a-u", db.tc2);
        texts.textField("Prefix", "<ZPK>", db.prefix);
        texts.toggle("Send Total offset in chat", db.sendos);
        texts.toggle("Send offset x in chat", db.sendosx);
        texts.toggle("Send offset z in chat", db.sendosz);
        texts.toggle("Send Total PB in chat", db.sendpb);
        texts.toggle("Send PB x in chat", db.sendpbx);
        texts.toggle("Send PB z in chat", db.sendpbz);
        forceShow(player, texts).then((texts) => {
            if (texts.canceled)
                return settingUI(player);
            db.tc1 = texts.formValues[0];
            db.tc2 = texts.formValues[1];
            db.prefix = texts.formValues[2];
            db.sendos = texts.formValues[3];
            db.sendosx = texts.formValues[4];
            db.sendosz = texts.formValues[5];
            db.sendpb = texts.formValues[6];
            db.sendpbx = texts.formValues[7];
            db.sendpbz = texts.formValues[8];
        });
    });
}
/*Other UI*/
function OtherUI(player) {
    run(() => {
        const db = Database(player);
        const other = new ui.ModalFormData();
        other.title("Other Setting");
        other.slider("Offset limit", 0.1, 1.5, 0.1);
        other.textField("Custom Text", "text", db.customText);
        forceShow(player, other).then((other) => {
            if (other.canceled)
                return settingUI(player);
            db.os = +other.formValues[0].toFixed(1);
            db.customText = other.formValues[1];
        });
    });
}
const run = (callback) => system.run(callback);
async function forceShow(player, form) {
    while (true) {
        const response = await form.show(player);
        if (response.cancelationReason !== ui.FormCancelationReason.UserBusy) {
            return response;
        }
    }
}
