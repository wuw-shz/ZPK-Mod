import { cmdPrefix } from "config";
export const configuration = {
    prefix: cmdPrefix,
    multiThreadingEnabled: true,
    multiThreadingTimeBudget: 32, // How long (in milliseconds) active threads are allowed to run before pausing a bit
};
