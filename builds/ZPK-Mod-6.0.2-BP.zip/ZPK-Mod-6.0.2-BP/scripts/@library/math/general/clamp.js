// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Clamps the passed in number to the passed in min and max values.
 *
 * @public
 */
export function clampNumber(val, min, max) {
    return Math.min(Math.max(val, min), max);
}
