export const zpkModOn = true;
export const cmdPrefix = ".";
export const version = "6.0.1";
export const zpkItems = {};
